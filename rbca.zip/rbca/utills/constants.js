module.exports = {
    roles: {
      admin: 'ADMIN',
      editor: 'EDITOR',
      client: 'CLIENT',
    },
  };